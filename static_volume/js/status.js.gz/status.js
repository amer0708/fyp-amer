document.addEventListener('DOMContentLoaded', function() {
    // Any specific JavaScript for status page can go here
    console.log('Order Status page loaded');
});